import React, { Component } from 'react'
import Header from './Header'

export default class BaiTapLayout1 extends Component {

    render() {
        return (
            <div>
                <Header />
                <div className="row">
                    <div className="col-4">
                        
                    </div>
                    <div className="col-8">

                    </div>
                </div>
            </div>
        )
    }
}
